import ocr_findnum_position as fn
import cv2
import numpy as np


def picshadow_x(pre_img):
    shadow_x = []
    print(np.shape(pre_img))
    x_sum = np.sum(pre_img, 0)
    print(np.shape(x_sum))
    # print(shadow_y)


def num_black(pre_img):
    length_x = len(pre_img[0])
    print(length_x)
    black_num = [0] * length_x
    # for img_x in pre_img:
    #     for i, img_y in enumerate(img_x):

num_img= fn.num_img
num_img_threshold = fn.num_img_threshold
cv2.imshow('num_img_threshold', num_img_threshold)
cv2.waitKey()
num_black(num_img_threshold)