import numpy as np
a = [1 ,2 ,3 ,4]

b = []
for i in range(len(a)):
    a[i] = a[i] + 2
a.append(b)
print(b == None)