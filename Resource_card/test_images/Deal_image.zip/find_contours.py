"""
提取出银行卡卡的轮廓
"""
import imutils
import cv2
import numpy as np
import math

# 银行卡目录
PIC_DIR = './Resource_card/test_images/'
# 确定图片四周的宽度内做筛选银行卡边框，这个宽度定为50
tempWidth = 60
# 图片Resize大小
pic_width = 500
pic_height = 360


# 读取图片
crad_img = cv2.imread(PIC_DIR + '1.jpeg')
crad_img = imutils.resize(crad_img, width=pic_width, height=pic_height)
msf_image = cv2.pyrMeanShiftFiltering(crad_img, 30, 20)  # 均值偏移滤波降噪
# msf_image = cv2.GaussianBlur(crad_img, (3, 3), 1)
crad_img2gray = cv2.cvtColor(msf_image, cv2.COLOR_RGB2GRAY)  # 灰度处理
canny_img = cv2.Canny(crad_img2gray, 50, 100)
cv2.imshow('canny', canny_img)
threshold = cv2.threshold(canny_img, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
cnts = cv2.findContours(threshold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]  # 提取最外层的信息
max_s = 0
max_list = [0, 0, 0, 0]
for i in range(0, len(cnts)):
    x, y, w, h = cv2.boundingRect(cnts[i])
    s = w * h
    if s > max_s:
        print(w * h)
        max_s = s
        max_list[0] = x
        max_list[1] = y
        max_list[2] = w
        max_list[3] = h
cv2.rectangle(crad_img, (max_list[0], max_list[1]), (max_list[0]+max_list[2], max_list[1]+max_list[3]), (153,153,0), 1)
cv2.imshow("crad_img", crad_img)
cv2.waitKey()

